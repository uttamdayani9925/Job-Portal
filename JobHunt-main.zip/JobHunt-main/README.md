# JobHunt
JobHunt is online job finding platform with supports Machine Learning feature which are beneficial for Recruiter 
