import React from 'react'

function ResetPassword() {
  return (
    <div>ResetPassword</div>
  )
}

export default ResetPassword